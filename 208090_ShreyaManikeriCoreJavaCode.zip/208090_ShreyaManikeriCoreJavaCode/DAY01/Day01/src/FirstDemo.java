class FirstDemo{
public static void main(String[] args){
System.out.println("Helllo");
}
}